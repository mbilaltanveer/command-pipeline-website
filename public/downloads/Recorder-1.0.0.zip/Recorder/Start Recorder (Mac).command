#!/bin/bash
# Opens Recorder in its own window, using Chrome, Edge, Brave or Chromium if you have one.
# Otherwise it opens in your default browser.
cd "$(dirname "$0")" || exit 1
APP="$(pwd)/app/index.html"
URL="file://$(printf '%s' "$APP" | sed -e 's/%/%25/g' -e 's/ /%20/g' -e 's/#/%23/g' -e 's/?/%3F/g')"

for BROWSER in "Google Chrome" "Microsoft Edge" "Brave Browser" "Chromium"; do
  if [ -d "/Applications/$BROWSER.app" ] || [ -d "$HOME/Applications/$BROWSER.app" ]; then
    open -na "$BROWSER" --args --app="$URL"
    exit 0
  fi
done

open "$APP"
