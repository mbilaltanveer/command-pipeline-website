<p align="center"><img src="docs/icon.png" width="96" alt=""></p>

<h1 align="center">Recorder</h1>

<p align="center"><b>A free, open-source screen and camera recorder.</b><br>
Record your screen with your face in a bubble, see exactly what you're recording, and get an MP4 on your own computer.<br>
No account. No watermark. No time limit. Nothing is uploaded.</p>

<p align="center"><img src="docs/screenshot-recording.png" width="720" alt="Recorder while recording: a slide with a round camera bubble in the corner and a live preview"></p>

---

## What it does

- **Three ways to record:** Screen + Camera (like Loom), Screen only, or Camera only
- **Round camera bubble** in any corner, in three sizes
- **Live preview** while you record, showing exactly what ends up in the video
- **Pause and resume**, a 3-second countdown, and a microphone level meter
- **720p, 1080p or 1440p** quality
- **Saves MP4 files** to a folder you choose, or to your Downloads folder
- **Crash-safe:** if the window closes mid-recording, Recorder offers to save what was recorded the next time you open it
- **Works on Mac and Windows**, in Google Chrome or Microsoft Edge (Edge comes with every Windows PC)

<p align="center"><img src="docs/screenshot-setup.png" width="520" alt="Recorder's setup screen with mode buttons, camera bubble preview and settings"></p>

---

## Get started

Pick whichever is easiest. Both are free and work the same way.

### Option A: use it online (nothing to download)

1. Open **https://mbilaltanveer.github.io/recorder/** in Chrome or Edge.
2. Optional: click **Install app** at the top right. Recorder then gets its own icon in your Dock, Applications or Start menu, opens in its own window, and works offline.

Your videos still stay on your computer. The page only runs the recorder; it never receives your recordings.

### Option B: download it

1. Download **Recorder-1.0.0.zip** from the [Releases page](https://github.com/mbilaltanveer/recorder/releases), or click **Code → Download ZIP** on this page.
2. Unzip it.
3. Open it:

| On a **Mac** | On **Windows** |
|---|---|
| Double-click **Start Recorder (Mac)**. | Double-click **Start Recorder (Windows)**. |
| The first time, macOS may say it can't check the file. **Right-click → Open**, or go to **System Settings → Privacy & Security** and click **Open Anyway**. | The first time, Windows may show "Windows protected your PC". Click **More info → Run anyway**. |

You'll only see those warnings once. They appear because the starter files aren't signed by a paid developer account, not because anything is wrong.

You can also just open `app/index.html` in Chrome or Edge.

---

## First-time setup (one minute)

**1. Allow the camera and microphone.** Your browser asks when Recorder opens. Click **Allow**.

**2. Allow screen recording.**
- **Mac:** the first time you press Start, macOS may block it. Go to **System Settings → Privacy & Security → Screen & System Audio Recording**, turn on your browser (Chrome or Edge), then quit and reopen the browser.
- **Windows:** nothing to do.

**3. Choose where videos go** (Chrome and Edge). Under **Save videos to**, click **Choose a folder…** and pick or create a folder such as *Videos → Recorder*. Otherwise videos go to your Downloads folder.

If something gets blocked, Recorder shows a message saying exactly where to fix it.

---

## Recording

1. Choose **Screen + Camera**, **Screen only** or **Camera only**.
2. Pick the bubble corner and size, and the quality.
3. Press **Start recording**, then choose what to share: your **entire screen**, **one window**, or **one browser tab**.
4. Switch to what you're presenting. Come back to the Recorder window any time to see the live preview.
5. Press **Stop & save**, or click **Stop sharing** in the browser's bar. The video is saved immediately and plays right there.

### Tips

- **Recording the entire screen?** Keep the Recorder window behind what you're presenting. Otherwise the recording shows Recorder showing itself, like a hall of mirrors. You can also click **Hide preview**, or share a single window instead.
- **Want sound from a video or tab?** Share a **browser tab** and tick **Also share tab audio** in the share picker.
- **Better results:** face a window for light, raise your laptop so the camera is at eye level, and use headphones with a mic if you can.

---

## Which browsers work?

| Browser | Works? | Notes |
|---|---|---|
| **Google Chrome** (Mac & Windows) | ✅ Best | Saves to any folder you choose. Can install as an app. |
| **Microsoft Edge** (Mac & Windows) | ✅ Best | Same as Chrome. Built into Windows. |
| Brave, Opera, Arc, other Chromium browsers | ✅ | Folder saving depends on the browser. |
| Safari (Mac) | ⚠️ Basic, less tested | Saves to Downloads. Keep the Recorder window visible while recording. |
| Firefox | ⚠️ Basic, less tested | Saves WebM instead of MP4. Keep the Recorder window visible while recording. |

For the best results, use Chrome or Edge.

---

## Questions

**Where are my videos?**
In the folder you chose under *Save videos to*, or in your **Downloads** folder. The list at the bottom of Recorder shows them too.

**Is anything uploaded?**
No. Recording, the bubble, and saving all happen inside your browser on your computer. Recorder has no server, no account and no analytics.

**The camera says "blocked".**
Follow the message in Recorder. Usually it means clicking the icon at the left of the address bar and setting Camera to Allow. On a Mac it can also mean turning your browser on in System Settings → Privacy & Security → Camera.

**The browser asks to "allow multiple downloads".**
That happens when saving several videos to Downloads in one go. Click **Allow**, or choose a folder under *Save videos to* and it won't ask again.

**The browser asks me to let Recorder edit files in my folder again.**
Browsers ask once per visit for safety. Install Recorder as an app (Option A) and choose "Allow on every visit" if offered.

**Do the videos work everywhere?**
Yes. They're standard MP4 files (H.264 video, AAC audio) that play in QuickTime, Windows Media Player, VLC, WhatsApp, LinkedIn, YouTube and so on.

---

## Put it on your own website

Recorder is a single web page with no server. Upload the contents of the `app` folder to any web host and it works. The address must start with `https://` for cameras and installing to work.

**Using GitHub Pages (free):**
1. Fork this repository (or copy it into your own repository named `recorder`).
2. Open the repository's **Settings → Pages** and set **Source** to **GitHub Actions**.
3. Push to `main`. The included workflow publishes the app to `https://<your-github-username>.github.io/recorder/`.

**Making a download ZIP:** run `scripts/make-release.sh 1.0.0`. It creates `release/Recorder-1.0.0.zip`. Or push a tag (`git tag v1.0.0 && git push origin v1.0.0`) and the included workflow attaches the ZIP to a GitHub release automatically.

To show a link back to your GitHub page in the app's header, set `REPO_URL` near the top of the script in `app/index.html`.

---

## For developers

Everything lives in `app/index.html`: plain HTML, CSS and JavaScript, with no build step and no dependencies.

- The camera bubble is drawn into the video with `MediaStreamTrackProcessor` / `MediaStreamTrackGenerator`, so it keeps working while the window is in the background. Other browsers fall back to a canvas.
- Video is recorded with `MediaRecorder` (MP4 in Chromium and Safari), saved with the File System Access API or a normal download, and backed up in IndexedDB while recording so it can be recovered after a crash.
- `app/sw.js` and `app/manifest.webmanifest` make it installable and usable offline.

**Self-test:** open `index.html?selftest=1&mode=screen-cam&seconds=5` in Chrome started with `--use-fake-device-for-media-stream --use-fake-ui-for-media-stream`. It records a demo screen with a fake camera and downloads the result. `mode` can be `screen-cam`, `screen` or `cam`.

Contributions are welcome: open an issue or a pull request.

## License

[MIT](LICENSE): free to use, change and share, including commercially.
