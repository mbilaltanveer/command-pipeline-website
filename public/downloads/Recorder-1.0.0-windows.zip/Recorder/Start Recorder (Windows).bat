@echo off
rem Opens Recorder in its own window, using Chrome or Edge (Edge comes with every Windows PC).
setlocal
set "APP=%~dp0app\index.html"
set "URL=file:///%APP:\=/%"
set "BROWSER="
for %%B in (
  "%ProgramFiles%\Google\Chrome\Application\chrome.exe"
  "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
  "%LocalAppData%\Google\Chrome\Application\chrome.exe"
  "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
  "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
) do (
  if not defined BROWSER if exist %%B set "BROWSER=%%~B"
)
if defined BROWSER (
  start "" "%BROWSER%" --app="%URL%"
) else (
  start "" "%APP%"
)
endlocal
